package br.unicap.poo.atividade.questao2;

public class Aluno {
    private String nome;
    private int idade;
    private String serie;

    public Aluno(){}

    public Aluno(String nome, int idade, String serie) {
        this.nome = nome;
        this.serie = serie;
        this.idade = idade;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return this.nome;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public int getIdade(){
        return this.idade;
    }

    public void setSerie(String serie) {
        this.serie = serie;
    }

    public String getSerie() {
        return this.serie;
    }
}
