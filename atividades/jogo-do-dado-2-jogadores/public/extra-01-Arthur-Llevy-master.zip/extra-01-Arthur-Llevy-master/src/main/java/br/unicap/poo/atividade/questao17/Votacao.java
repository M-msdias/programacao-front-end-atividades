package br.unicap.poo.atividade.questao17;

public class Votacao {
    private String candidado;
    private int votosRecebidos;

    public Votacao() {}

    public Votacao(String candidado, int votosRecebidos) {
        this.candidado = candidado;
        this.votosRecebidos = votosRecebidos;
    }

    public void adicionaVoto() {
        setVotosRecebidos(getVotosRecebidos() + 1);
    }

    public void zerarVotos() {
        setVotosRecebidos(0);
    }

    public void exibirResultado() {
        System.out.println("Nome: " + getCandidado() + "quantidade de votos recebidos: " + getVotosRecebidos());
    }

    public void compararVotacao(Votacao outraVotacao) {
        if (getVotosRecebidos() > outraVotacao.getVotosRecebidos()) {
            System.out.println("O candidato " + getCandidado() + " foi o vencedor. \n " + getVotosRecebidos() + "x" + outraVotacao.getVotosRecebidos());
        } else if (getVotosRecebidos() < outraVotacao.getVotosRecebidos()) {
            System.out.println("O candidato " + outraVotacao.getCandidado() + " foi o vencedor. \n " + outraVotacao.getVotosRecebidos() + "x" + getVotosRecebidos());
        } else {
            System.out.println("Ambos candidatos receberam a mesma quantidade de votos.");
        }
    }

    public String getCandidado() {
        return candidado;
    }

    public void setCandidado(String candidado) {
        this.candidado = candidado;
    }

    public int getVotosRecebidos() {
        return votosRecebidos;
    }

    public void setVotosRecebidos(int votosRecebidos) {
        this.votosRecebidos = votosRecebidos;
    }
}
