package br.unicap.poo.atividade.questao9;

public class Main {
    public static void main(String[] args) {
        Paciente paciente1 = new Paciente("José", 50, "Diabetes");
        Paciente paciente2 = new Paciente("Arnaldo", 80, "Gripe leve");
        Paciente paciente3 = new Paciente("João", 20, "Dengue");

        paciente1.mostrarInformacoes();
        paciente2.mostrarInformacoes();
        paciente3.mostrarInformacoes();
    }
}
