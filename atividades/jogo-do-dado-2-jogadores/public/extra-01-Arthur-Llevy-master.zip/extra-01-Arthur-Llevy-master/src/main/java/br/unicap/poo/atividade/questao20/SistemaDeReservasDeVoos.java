package br.unicap.poo.atividade.questao20;

import java.util.ArrayList;

public class SistemaDeReservasDeVoos {
    ArrayList<ReservaDeVoo> reservasDeVoos = new ArrayList<ReservaDeVoo>();

    public void adicionarReserva(ReservaDeVoo novaReserva) {
        reservasDeVoos.add(novaReserva);
    }

    public void cancelarReserva(ReservaDeVoo reservaParaCancelar) {
        if (reservasDeVoos.contains(reservaParaCancelar)) {
            reservasDeVoos.remove(reservaParaCancelar);
        }
    }

    public boolean confirmarReserva(ReservaDeVoo reversaParaConfirmar) {
        return reservasDeVoos.contains(reversaParaConfirmar);
    }
}
