package br.unicap.poo.atividade.questao8;

public class Main {
    public static void main(String[] args) {
        Evento evento1 = new Evento("Festa de João", "10/05/2025", "Restaurante Capitão Gancho");
        Evento evento2 = new Evento("Colação de Grau, Turma Sin 2024.2", "10/06/2026", "UNICAP");
        Evento evento3 = new Evento("Congresso de Pesquisa Científica", "20/07/2025", "UFPE");

        evento1.mostrarInformacoes();
        evento2.mostrarInformacoes();
        evento3.mostrarInformacoes();
    }
}
