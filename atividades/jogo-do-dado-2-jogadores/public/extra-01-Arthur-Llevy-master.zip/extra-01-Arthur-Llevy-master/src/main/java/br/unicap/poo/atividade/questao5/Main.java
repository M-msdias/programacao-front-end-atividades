package br.unicap.poo.atividade.questao5;

public class Main {
    public static void main(String[] args) {
        Hotel reserva1 = new Hotel("Arthur", "Simples", 3);
        Hotel reserva2 = new Hotel("Levy", "Duplo", 4);
        Hotel reserva3 = new Hotel("Antonio", "Suite", 9);

        reserva1.mostrarInformacoes();
        reserva2.mostrarInformacoes();
        reserva3.mostrarInformacoes();
    }
}
