package br.unicap.poo.atividade.questao16;

public class Curso {
    private String nome;
    private String categoria;
    private int cargaHoraria;
    private int numeroDeAlunosInscritos;

    public Curso(){}

    public Curso(String nome, String categoria, int cargaHoraria, int numeroDeAlunosInscritos) {
        this.nome = nome;
        this.categoria = categoria;
        this.cargaHoraria = cargaHoraria;
        this.numeroDeAlunosInscritos = numeroDeAlunosInscritos;
    }

    public void inscreverAluno(){
        setNumeroDeAlunosInscritos(getNumeroDeAlunosInscritos() + 1);
    }

    public void cancelarInscricao() {
        if (getNumeroDeAlunosInscritos() > 0) {
            setNumeroDeAlunosInscritos(getNumeroDeAlunosInscritos() - 1);
        }
    }

    public void atualizarCargaHoraria(int novaCargaHoraria) {
        setCargaHoraria(novaCargaHoraria);
    }

    public void mostrarInformacoes() {
        System.out.println("Nome: " + getNome() + ", categoria: " + getCategoria() + ", carga horária: " + getCargaHoraria() + ", número de alunos inscritos: " + getNumeroDeAlunosInscritos());
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public int getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(int cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public int getNumeroDeAlunosInscritos() {
        return numeroDeAlunosInscritos;
    }

    public void setNumeroDeAlunosInscritos(int numeroDeAlunosInscritos) {
        this.numeroDeAlunosInscritos = numeroDeAlunosInscritos;
    }
}
