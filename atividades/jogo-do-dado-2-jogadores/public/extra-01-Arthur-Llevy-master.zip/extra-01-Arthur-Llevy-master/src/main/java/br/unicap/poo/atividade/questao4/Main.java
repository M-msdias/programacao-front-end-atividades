package br.unicap.poo.atividade.questao4;

public class Main {
    public static void main(String[] args) {
        Funcionario funcionario1 = new Funcionario("Arthur", "limpeza", 2100);
        Funcionario funcionario2 = new Funcionario("Levy", "suporte de T.I.", 3000);
        Funcionario funcionario3 = new Funcionario("Alonso", "tech lead", 5000);

        System.out.println("Detalhamanento de cada funcionário");
        System.out.println("########################");
        System.out.println("Funcionário 1");
        System.out.println("Nome: " + funcionario1.getNome() + ", departamento: " + funcionario1.getDepartamento() + " e salário: R$" + funcionario1.getSalario());
        System.out.println("\n");

        System.out.println("Funcionário 2");
        System.out.println("Nome: " + funcionario2.getNome() + ", departamento: " + funcionario2.getDepartamento() + " e salário: R$" + funcionario2.getSalario());
        System.out.println("\n");

        System.out.println("Funcionário 3");
        System.out.println("Nome: " + funcionario3.getNome() + ", departamento: " + funcionario3.getDepartamento() + " e salário: R$" + funcionario3.getSalario());
        System.out.println("\n");
    }
}
