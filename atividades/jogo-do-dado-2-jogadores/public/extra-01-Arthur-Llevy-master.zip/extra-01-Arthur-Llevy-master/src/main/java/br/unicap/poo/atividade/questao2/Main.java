package br.unicap.poo.atividade.questao2;

public class Main {
    public static void main(String[] args) {
        Aluno aluno1 = new Aluno("Arthur", 14, "9° ano");
        Aluno aluno2 = new Aluno("Levy", 11, "6° ano");
        Aluno aluno3 = new Aluno("Batista", 12, "7° ano");

        System.out.println("Dados aluno 1: \nNome: " + aluno1.getNome() + ", idade: " + aluno1.getIdade() + ", e série: " + aluno1.getSerie());
        System.out.println("Dados aluno 2: \nNome: " + aluno2.getNome() + ", idade: " + aluno2.getIdade() + ", e série: " + aluno2.getSerie());
        System.out.println("Dados aluno 3: \nNome: " + aluno3.getNome() + ", idade: " + aluno3.getIdade() + ", e série: " + aluno3.getSerie());
    }
}
