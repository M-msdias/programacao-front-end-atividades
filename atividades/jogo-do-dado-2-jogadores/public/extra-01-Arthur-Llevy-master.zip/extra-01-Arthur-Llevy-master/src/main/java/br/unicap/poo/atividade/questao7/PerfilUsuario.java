package br.unicap.poo.atividade.questao7;

public class PerfilUsuario {
    private String nome;
    private String bio;
    private int numeroSeguidores;

    public PerfilUsuario(){}

    public PerfilUsuario(String nome, String bio, int numeroSeguidores) {
        this.nome = nome;
        this.bio = bio;
        this.numeroSeguidores = numeroSeguidores;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public int getNumeroSeguidores() {
        return numeroSeguidores;
    }

    public void setNumeroSeguidores(int numeroSeguidores) {
        this.numeroSeguidores = numeroSeguidores;
    }

    public void mostrarInformacoes(){
        System.out.println("Nome do usuário: " + this.getNome() + ", bio: " + this.getBio() + ", número de seguidores: " + this.getNumeroSeguidores());
    }
}
