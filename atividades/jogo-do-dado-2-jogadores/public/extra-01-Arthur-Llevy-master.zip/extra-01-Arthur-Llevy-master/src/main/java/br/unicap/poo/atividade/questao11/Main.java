package br.unicap.poo.atividade.questao11;

public class Main {
    public static void main(String[] args) {
        ContaCorrente contaCorrente1 = new ContaCorrente("123", 2000, "Arthur");
        ContaCorrente contaCorrente2 = new ContaCorrente("456", 7000, "Levy");

        contaCorrente1.transferir(contaCorrente2, 800);
        contaCorrente1.exibirSaldo();
        contaCorrente2.exibirSaldo();
    }
}
