package br.unicap.poo.atividade.questao20;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        SistemaDeReservasDeVoos sistemaDeReservasDeVoos = new SistemaDeReservasDeVoos();

        ReservaDeVoo reserva1 = new ReservaDeVoo("20", "Arthur", "1");
        ReservaDeVoo reserva2 = new ReservaDeVoo("32", "Batista", "2");
        ReservaDeVoo reserva3 = new ReservaDeVoo("24", "Vieira", "3");


        sistemaDeReservasDeVoos.adicionarReserva(reserva1);
        sistemaDeReservasDeVoos.adicionarReserva(reserva2);
        sistemaDeReservasDeVoos.adicionarReserva(reserva3);

        reserva1.exibirDetalhes();

        System.out.println("A reserva 1 está confirmada? " + sistemaDeReservasDeVoos.confirmarReserva(reserva1));
    }
}
