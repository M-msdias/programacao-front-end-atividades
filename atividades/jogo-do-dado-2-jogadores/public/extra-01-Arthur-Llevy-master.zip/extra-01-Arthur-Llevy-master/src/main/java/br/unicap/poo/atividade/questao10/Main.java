package br.unicap.poo.atividade.questao10;

public class Main {
    public static void main(String[] args) {
        Pedido pedido1 = new Pedido(1, "Batatas fritas", 10);
        Pedido pedido2 = new Pedido(2, "Almoço com suco", 20);
        Pedido pedido3 = new Pedido(3, "Água mineral", 2);

        pedido1.mostrarInformacoes();
        pedido2.mostrarInformacoes();
        pedido3.mostrarInformacoes();
    }
}
