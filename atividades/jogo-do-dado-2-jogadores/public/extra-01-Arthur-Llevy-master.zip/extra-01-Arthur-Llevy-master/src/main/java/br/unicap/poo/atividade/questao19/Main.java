package br.unicap.poo.atividade.questao19;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Transacao> transacoes = new ArrayList<Transacao>();

        Transacao transacao1 = new Transacao();

        transacao1.registrarTransacao(transacoes, new Transacao("Transação 1", 9000, "Setor de limpeza"));
        transacao1.registrarTransacao(transacoes, new Transacao("Transação 2", 180000, "Setor de TI"));
        transacao1.registrarTransacao(transacoes, new Transacao("Transação 3", 20000, "Setor financeiro"));

        transacao1.alterarDescricao("Transação realizada no dia 10/03");
        transacao1.exibirTransacao();

        System.out.println("Saldo total das transações: R$" + transacao1.calcularSaldo(transacoes));
    }
}
