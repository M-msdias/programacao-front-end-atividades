package br.unicap.poo.atividade.questao5;

public class Hotel {
    private String nomeHospede;
    private String tipoQuarto;
    private int quantidadeNoites;

    public Hotel(){}

    public Hotel(String nomeHospede, String tipoQuarto, int quantidadeNoites){
        this.nomeHospede = nomeHospede;
        this.tipoQuarto = tipoQuarto;
        this.quantidadeNoites = quantidadeNoites;
    }

    public String getNomeHospede() {
        return nomeHospede;
    }

    public void setNomeHospede(String nomeHospede) {
        this.nomeHospede = nomeHospede;
    }

    public String getTipoQuarto() {
        return tipoQuarto;
    }

    public void setTipoQuarto(String tipoQuarto) {
        this.tipoQuarto = tipoQuarto;
    }

    public int getQuantidadeNoites() {
        return quantidadeNoites;
    }

    public void setQuantidadeNoites(int quantidadeNoites) {
        this.quantidadeNoites = quantidadeNoites;
    }

    public void mostrarInformacoes() {
        System.out.println("Nome do hospede: " + this.getNomeHospede() + ", tipo de quarto: " + this.getTipoQuarto() + " e quantidade de noites reservadas: " + this.getQuantidadeNoites());
    }
}
