package br.unicap.poo.atividade.questao13;

public class Main {
    public static void main(String[] args) {
        Contato contato1 = new Contato("Arthur", "123456", "arthur@email.com");
        System.out.println(contato1.validaEmail());
    }
}
