package br.unicap.poo.atividade.questao7;

public class Main {
    public static void main(String[] args) {
        PerfilUsuario perfilUsuario1 = new PerfilUsuario("Arthur", "Desenvolvedor Full Stack, pós graduando em Engenharia da Computação - Upe", 9000);
        PerfilUsuario perfilUsuario2 = new PerfilUsuario("Levy", "Biólogo, doutorando em ciências da Saúde", 12000);
        PerfilUsuario perfilUsuario3 = new PerfilUsuario("José", "Eletricista formado pela UFPE", 200);

        perfilUsuario1.mostrarInformacoes();
        perfilUsuario2.mostrarInformacoes();
        perfilUsuario3.mostrarInformacoes();
    }
}
