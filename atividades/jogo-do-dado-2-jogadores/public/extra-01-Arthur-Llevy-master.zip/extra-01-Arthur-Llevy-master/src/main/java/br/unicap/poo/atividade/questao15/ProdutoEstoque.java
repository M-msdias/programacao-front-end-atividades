package br.unicap.poo.atividade.questao15;

public class ProdutoEstoque {
    private String nome;
    private int quantidade;
    private double precoUnitario;

    public ProdutoEstoque(){}

    public ProdutoEstoque(String nome, int quantidade, double precoUnitario) {
        this.nome = nome;
        this.quantidade = quantidade;
        this.precoUnitario = precoUnitario;
    }

    public void adicionarEstoque(int quantidade) {
        setQuantidade(getQuantidade() + quantidade);
    }

    public void removeEsqtoque(int quantidade) {
        if (getQuantidade() > 0 && quantidade <= getQuantidade()) {
            setQuantidade(getQuantidade() - quantidade);
        }
    }

    public void atualizarPreco(double novoPreco) {
        setPrecoUnitario(novoPreco);
    }

    public void exibirProduto() {
        System.out.println("Nome: " + getNome() + ", quantidade: " + getQuantidade() + "m preço unitário: " + getPrecoUnitario());
    }


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getPrecoUnitario() {
        return precoUnitario;
    }

    public void setPrecoUnitario(double precoUnitario) {
        this.precoUnitario = precoUnitario;
    }
}
