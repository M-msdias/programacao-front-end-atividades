package br.unicap.poo.atividade.questao15;

public class Main {
    public static void main(String[] args) {
        ProdutoEstoque produtoEstoque1 = new ProdutoEstoque("Arroz", 20, 12);
    }
}
