package br.unicap.poo.atividade.questao14;

public class GerenciadorDeTarefas {
    private String descricao;
    private boolean concluida;
    private int prioridade;

    public GerenciadorDeTarefas(){}

    public GerenciadorDeTarefas(String descricao, boolean concluida, int prioridade) {
        this.descricao = descricao;
        this.concluida = concluida;
        this.prioridade = prioridade;
    }

    public void concluiTarefa() {
        setConcluida(true);
    }

    public void mudarPrioridade(int novaPrioridade) {
        setPrioridade(novaPrioridade);
    }

    public void exibirTarefa() {
        System.out.println("Descrição: "+ getDescricao() + ", concluída: " + isConcluida());
    }

    public void resetarTarefa() {
        setConcluida(false);
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public boolean isConcluida() {
        return concluida;
    }

    public void setConcluida(boolean concluida) {
        this.concluida = concluida;
    }

    public int getPrioridade() {
        return prioridade;
    }

    public void setPrioridade(int prioridade) {
        this.prioridade = prioridade;
    }
}
