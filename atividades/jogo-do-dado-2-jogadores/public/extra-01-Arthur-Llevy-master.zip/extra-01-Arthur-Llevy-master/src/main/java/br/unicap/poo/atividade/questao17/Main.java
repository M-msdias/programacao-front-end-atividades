package br.unicap.poo.atividade.questao17;

public class Main {
    public static void main(String[] args) {
        Votacao votacao1 = new Votacao("Arthur", 201);
        Votacao votacao2 = new Votacao("Levy", 201);

        votacao1.compararVotacao(votacao2);
    }
}
