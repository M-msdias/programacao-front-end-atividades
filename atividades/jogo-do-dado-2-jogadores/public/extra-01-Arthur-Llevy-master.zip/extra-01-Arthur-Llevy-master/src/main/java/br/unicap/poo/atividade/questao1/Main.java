package br.unicap.poo.atividade.questao1;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void adicionaLivro(ArrayList<Livro> listaLivros, Livro livro) {
        listaLivros.add(livro);
        System.out.println("Novo livro adicionado com sucesso!. Título: " + livro.getTitulo() + ", autor: " + livro.getAutor() + " e ano de publicação: " + livro.getAnoPublicacao());
    }
    
    public static void mostraInformacoesLivros(ArrayList<Livro> listaLivros) {
        for (int i = 0; i < listaLivros.size(); i++) {
            System.out.println("Descrição do livro " + (i + 1) +  "\n Título: " + listaLivros.get(i).getTitulo() + ", autor: " + listaLivros.get(i).getAutor() + " e ano de publicação: " + listaLivros.get(i).getAnoPublicacao());
            System.out.println("------------------------------------------------");
        }
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        ArrayList<Livro> listaLivros = new ArrayList<Livro>(){};

        for (int i = 1; i <= 3; i++) {
            System.out.println("Digite o título do livro " + i);
            String titulo = scan.nextLine();

            System.out.println("Digite o autor do livro " + i);
            String autor = scan.nextLine();

            System.out.println("Digite o ano de publicação do livro " + i);
            int anoPublicacao = scan.nextInt();
            scan.nextLine();

            Livro novoLivro = new Livro(titulo, autor, anoPublicacao);
            adicionaLivro(listaLivros, novoLivro);
        }

        scan.close();

        mostraInformacoesLivros(listaLivros);
    }
}
