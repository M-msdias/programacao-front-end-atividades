package br.unicap.poo.atividade.questao18;

public class Main {
    public static void main(String[] args) {
        AtividadeFisica atividadeFisica1 = new AtividadeFisica("Correr na praia", 2, 500);
        AtividadeFisica atividadeFisica2 = new AtividadeFisica("Jogar vôlei", 1, 500);

        atividadeFisica1.compararCalorias(atividadeFisica2);

    }
}
