package br.unicap.poo.atividade.questao11;

public class ContaCorrente {
    private String numeroDaConta;
    private double saldo;
    private String nomeDoTitular;

    public ContaCorrente(){};

    public ContaCorrente(String numeroDaConta, double saldo, String nomeDoTitular) {
        this.numeroDaConta = numeroDaConta;
        this.saldo = saldo;
        this.nomeDoTitular = nomeDoTitular;
    }

    public void depositar(double valor) {
        setSaldo(getSaldo() + valor);
    }

    public void sacar(double valor) {
        if (getSaldo() > 0 && valor <= getSaldo()) {
            setSaldo(getSaldo() - valor);
        }
    }

    public void transferir(ContaCorrente destino, double valor) {
        if (getSaldo() > 0 && valor <= getSaldo()) {
            destino.setSaldo(destino.getSaldo() + valor);
            setSaldo(getSaldo() - valor);
        }
    }

    public void exibirSaldo() {
        System.out.println("Seu saldo atual é de R$: " + getSaldo());
    }

    public String getNumeroDaConta() {
        return numeroDaConta;
    }

    public void setNumeroDaConta(String numeroDaConta) {
        this.numeroDaConta = numeroDaConta;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String getNomeDoTitular() {
        return nomeDoTitular;
    }

    public void setNomeDoTitular(String nomeDoTitular) {
        this.nomeDoTitular = nomeDoTitular;
    }
}
