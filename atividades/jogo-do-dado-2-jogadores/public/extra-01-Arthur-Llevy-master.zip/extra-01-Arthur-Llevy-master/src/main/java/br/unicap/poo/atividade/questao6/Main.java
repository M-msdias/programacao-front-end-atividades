package br.unicap.poo.atividade.questao6;

public class Main {
    public static void main(String[] args) {
        Veiculo veiculo1 = new Veiculo("122-absc", "Toyota", 2020);
        Veiculo veiculo2 = new Veiculo("143-abmn", "Fiat", 1990);
        Veiculo veiculo3 = new Veiculo("190-azas", "Hyundai", 2007);

        veiculo1.mostrarInformacoes();
        veiculo2.mostrarInformacoes();
        veiculo3.mostrarInformacoes();
    }
}
