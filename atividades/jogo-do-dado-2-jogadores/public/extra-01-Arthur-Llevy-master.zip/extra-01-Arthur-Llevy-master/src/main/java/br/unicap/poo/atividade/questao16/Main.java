package br.unicap.poo.atividade.questao16;

public class Main {
    public static void main(String[] args) {
        Curso curso1 = new Curso("Curso de POO", "Curso de programação", 120, 90);
    }
}
