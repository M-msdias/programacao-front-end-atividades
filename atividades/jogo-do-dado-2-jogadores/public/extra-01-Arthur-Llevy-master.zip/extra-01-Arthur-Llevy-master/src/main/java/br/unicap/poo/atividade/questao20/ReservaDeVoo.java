package br.unicap.poo.atividade.questao20;

public class ReservaDeVoo {
    private String numeroDoVoo;
    private String nomeDoPassageiro;
    private String classe;

    public ReservaDeVoo(){}

    public ReservaDeVoo(String numeroDoVoo, String nomeDoPassageiro, String classe) {
        this.numeroDoVoo = numeroDoVoo;
        this.nomeDoPassageiro = nomeDoPassageiro;
        this.classe = classe;
    }

    public void alterarClasse(String novaClase) {
        setClasse(novaClase);
    }

    public void exibirDetalhes() {
        System.out.println("Número do voo: " + getNumeroDoVoo() + ", nome do passageiro: " + getNomeDoPassageiro() + ", classe: " + getClasse());
    }

    public String getNumeroDoVoo() {
        return numeroDoVoo;
    }

    public void setNumeroDoVoo(String numeroDoVoo) {
        this.numeroDoVoo = numeroDoVoo;
    }

    public String getNomeDoPassageiro() {
        return nomeDoPassageiro;
    }

    public void setNomeDoPassageiro(String nomeDoPassageiro) {
        this.nomeDoPassageiro = nomeDoPassageiro;
    }

    public String getClasse() {
        return classe;
    }

    public void setClasse(String classe) {
        this.classe = classe;
    }
}
