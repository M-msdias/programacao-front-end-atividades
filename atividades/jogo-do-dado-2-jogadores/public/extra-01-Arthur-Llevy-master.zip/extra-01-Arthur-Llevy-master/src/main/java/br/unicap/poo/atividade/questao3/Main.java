package br.unicap.poo.atividade.questao3;

public class Main {
    public static void main(String[] args) {
        Produto produto1 = new Produto("Arroz", 12.50, "Produto grosso");
        Produto produto2 = new Produto("Café", 40.20, "Produto grosso");
        Produto produto3 = new Produto("Bolo de rolo", 10.29, "Sobremesa");

        System.out.println("Dados do produto 1 \n" + "Nome: " + produto1.getNome() + ", preço: " + produto1.getPreco() + " e categoria: " + produto1.getCategoria());
        System.out.println("Dados do produto 2 \n" + "Nome: " + produto2.getNome() + ", preço: " + produto2.getPreco() + " e categoria: " + produto2.getCategoria());
        System.out.println("Dados do produto 3 \n" + "Nome: " + produto3.getNome() + ", preço: " + produto3.getPreco() + " e categoria: " + produto3.getCategoria());
    }
}
