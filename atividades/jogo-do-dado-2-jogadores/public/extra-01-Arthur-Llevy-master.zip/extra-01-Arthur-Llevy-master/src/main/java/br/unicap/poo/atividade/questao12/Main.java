package br.unicap.poo.atividade.questao12;

public class Main {
    public static void main(String[] args) {
        SessaoCinema sessaoCinema1 = new SessaoCinema("O Mágino de Oz", "14h", 60, 20);
        sessaoCinema1.exibirInforSessao();
    }
}
