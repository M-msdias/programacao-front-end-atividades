package br.unicap.poo.atividade.questao14;

public class Main {
    public static void main(String[] args) {
        GerenciadorDeTarefas tarefa1 = new GerenciadorDeTarefas("Limpar computador", false, 2);
        tarefa1.concluiTarefa();
        tarefa1.exibirTarefa();
    }
}
