package br.unicap.poo.atividade.questao12;

public class SessaoCinema {
    private String filme;
    private String horario;
    private int capacidadeTotal;
    private int ingressosVendidos;

    public SessaoCinema(){}

    public SessaoCinema(String filme, String horario, int capacidadeTotal, int ingressosVendidos) {
        this.filme = filme;
        this.horario = horario;
        this.capacidadeTotal = capacidadeTotal;
        this.ingressosVendidos = ingressosVendidos;
    }

    public void venderIngresso() {
        if (capacidadeTotal > 0) {
            setIngressosVendidos(getIngressosVendidos() + 1);
            setCapacidadeTotal(getCapacidadeTotal() - 1);
        }
    }

    public void cancelarIngresso() {
        setCapacidadeTotal(getCapacidadeTotal() + 1);
        setIngressosVendidos(getIngressosVendidos() - 1);
    }

    public void exibirInforSessao() {
        System.out.println("Dados da sessão\nFilme: " + getFilme() + ", horario: " + getHorario() + ", quantidade de lugares disponíveis: " + getCapacidadeTotal() + ", ingressos vendidos: " + getIngressosVendidos());
    }

    public void alterarHorario(String novoHorario) {
        setHorario(novoHorario);
    }

    public String getFilme() {
        return filme;
    }

    public void setFilme(String filme) {
        this.filme = filme;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public int getCapacidadeTotal() {
        return capacidadeTotal;
    }

    public void setCapacidadeTotal(int capacidadeTotal) {
        this.capacidadeTotal = capacidadeTotal;
    }

    public int getIngressosVendidos() {
        return ingressosVendidos;
    }

    public void setIngressosVendidos(int ingressosVendidos) {
        this.ingressosVendidos = ingressosVendidos;
    }
}
