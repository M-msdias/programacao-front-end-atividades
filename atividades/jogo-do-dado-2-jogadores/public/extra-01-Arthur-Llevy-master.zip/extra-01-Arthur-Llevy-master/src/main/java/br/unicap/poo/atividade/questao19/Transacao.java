package br.unicap.poo.atividade.questao19;

import java.util.ArrayList;

public class Transacao {
    private String descricacao;
    private double valor;
    private String tipo;

    public Transacao(){}

    public Transacao(String descricacao, double valor, String tipo) {
        this.descricacao = descricacao;
        this.valor = valor;
        this.tipo = tipo;
    }

    public void alterarDescricao(String novaDescricao){
        setDescricacao(novaDescricao);
    }

    public void exibirTransacao(){
        System.out.println("Descrição: " + getDescricacao() + ", valor: R$" + getValor() + ", tipo: "  + getTipo());
    }

    public void registrarTransacao(ArrayList<Transacao> transacoes, Transacao novaTransacao){
        transacoes.add(novaTransacao);
    }

    public double calcularSaldo(ArrayList<Transacao> transacoes) {
        double saldo = 0;
        for (Transacao transacao : transacoes) {
            saldo += transacao.getValor();
        }

        return saldo;
    }

    public String getDescricacao() {
        return descricacao;
    }

    public void setDescricacao(String descricacao) {
        this.descricacao = descricacao;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
