package br.unicap.poo.atividade.questao18;

public class AtividadeFisica {
    private String tipoDeAtividade;
    private int duracao;
    private int caloriasQueimadas;

    public AtividadeFisica() {}

    public AtividadeFisica(String tipoDeAtividade, int duracao, int caloriasQueimadas) {
        this.tipoDeAtividade = tipoDeAtividade;
        this.duracao = duracao;
        this.caloriasQueimadas = caloriasQueimadas;
    }

    public void registrarAtividade(int duracao) {
        setCaloriasQueimadas(duracao * 245);
    }

    public void alterarTipoDeAtividade(String novoTipo) {
        setTipoDeAtividade(novoTipo);
    }

    public void exibirAtividade() {
        System.out.println("Tipo de atividade: " + getTipoDeAtividade() + ", duração (em horas): " + getDuracao() + ", calorias queimadas: " + getCaloriasQueimadas());
    }

    public void compararCalorias(AtividadeFisica outraAtividadeFisica) {
        if (getCaloriasQueimadas() > outraAtividadeFisica.getCaloriasQueimadas()) {
            System.out.println("A atividade física " + getTipoDeAtividade() + " queimou mais calorias que a atividade física " + outraAtividadeFisica.getTipoDeAtividade());
        } else if (getCaloriasQueimadas() < outraAtividadeFisica.getCaloriasQueimadas()) {
            System.out.println("A atividade física " + outraAtividadeFisica.getTipoDeAtividade() + " queimou mais calorias que a atividade física " + getTipoDeAtividade());
        } else {
            System.out.println("Ambas atividades queimaram a mesma quantidade de calorias.");
        }
    }

    public String getTipoDeAtividade() {
        return tipoDeAtividade;
    }

    public void setTipoDeAtividade(String tipoDeAtividade) {
        this.tipoDeAtividade = tipoDeAtividade;
    }

    public int getDuracao() {
        return duracao;
    }

    public void setDuracao(int duracao) {
        this.duracao = duracao;
    }

    public int getCaloriasQueimadas() {
        return caloriasQueimadas;
    }

    public void setCaloriasQueimadas(int caloriasQueimadas) {
        this.caloriasQueimadas = caloriasQueimadas;
    }
}
