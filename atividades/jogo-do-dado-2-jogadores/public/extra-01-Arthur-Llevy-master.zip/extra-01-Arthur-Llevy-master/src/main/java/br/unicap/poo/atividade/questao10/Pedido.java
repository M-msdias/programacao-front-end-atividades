package br.unicap.poo.atividade.questao10;

public class Pedido {
    private int numeroPedido;
    private String descricao;
    private double valor;

    public Pedido(){}

    public Pedido(int numeroPedido, String descricao, double valor) {
        this.numeroPedido = numeroPedido;
        this.descricao = descricao;
        this.valor = valor;
    }

    public int getNumeroPedido() {
        return numeroPedido;
    }

    public void setNumeroPedido(int numeroPedido) {
        this.numeroPedido = numeroPedido;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public void mostrarInformacoes() {
        System.out.println("Número do pedido: " + this.getNumeroPedido() + ", descrição do pedido: " + this.getDescricao() + " e valor total: " + this.getValor());
    }
}
